﻿namespace TcKimlikEntegrasyonu
{
    partial class SorgulamaEkranı
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textTcNumarasi = new System.Windows.Forms.TextBox();
            this.textAd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textSoyad = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textDogumYili = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BtnSorgula = new System.Windows.Forms.Button();
            this.labelKimlikSorgulama = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(46, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "TC Numarası:";
            // 
            // textTcNumarasi
            // 
            this.textTcNumarasi.Location = new System.Drawing.Point(154, 112);
            this.textTcNumarasi.Name = "textTcNumarasi";
            this.textTcNumarasi.Size = new System.Drawing.Size(237, 20);
            this.textTcNumarasi.TabIndex = 1;
            // 
            // textAd
            // 
            this.textAd.Location = new System.Drawing.Point(154, 137);
            this.textAd.Name = "textAd";
            this.textAd.Size = new System.Drawing.Size(237, 20);
            this.textAd.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(46, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ad :";
            // 
            // textSoyad
            // 
            this.textSoyad.Location = new System.Drawing.Point(154, 164);
            this.textSoyad.Name = "textSoyad";
            this.textSoyad.Size = new System.Drawing.Size(237, 20);
            this.textSoyad.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(46, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Soyad:";
            // 
            // textDogumYili
            // 
            this.textDogumYili.Location = new System.Drawing.Point(154, 190);
            this.textDogumYili.Name = "textDogumYili";
            this.textDogumYili.Size = new System.Drawing.Size(237, 20);
            this.textDogumYili.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(46, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Doğum Yılı:";
            // 
            // BtnSorgula
            // 
            this.BtnSorgula.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSorgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.BtnSorgula.ForeColor = System.Drawing.Color.White;
            this.BtnSorgula.Location = new System.Drawing.Point(208, 216);
            this.BtnSorgula.Name = "BtnSorgula";
            this.BtnSorgula.Size = new System.Drawing.Size(140, 36);
            this.BtnSorgula.TabIndex = 8;
            this.BtnSorgula.Text = "Sorgula";
            this.BtnSorgula.UseVisualStyleBackColor = true;
            this.BtnSorgula.Click += new System.EventHandler(this.Sorgula_Click);
            // 
            // labelKimlikSorgulama
            // 
            this.labelKimlikSorgulama.AutoSize = true;
            this.labelKimlikSorgulama.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelKimlikSorgulama.ForeColor = System.Drawing.Color.White;
            this.labelKimlikSorgulama.Location = new System.Drawing.Point(113, 55);
            this.labelKimlikSorgulama.Name = "labelKimlikSorgulama";
            this.labelKimlikSorgulama.Size = new System.Drawing.Size(173, 20);
            this.labelKimlikSorgulama.TabIndex = 9;
            this.labelKimlikSorgulama.Text = "TC Kimlik Sorgulama";
            // 
            // SorgulamaEkranı
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(44)))), ((int)(((byte)(58)))));
            this.ClientSize = new System.Drawing.Size(788, 314);
            this.Controls.Add(this.labelKimlikSorgulama);
            this.Controls.Add(this.BtnSorgula);
            this.Controls.Add(this.textDogumYili);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textSoyad);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textAd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textTcNumarasi);
            this.Controls.Add(this.label1);
            this.Name = "SorgulamaEkranı";
            this.Text = "TcSorgulamaEkranı";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textTcNumarasi;
        private System.Windows.Forms.TextBox textAd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textSoyad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textDogumYili;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BtnSorgula;
        private System.Windows.Forms.Label labelKimlikSorgulama;
    }
}

