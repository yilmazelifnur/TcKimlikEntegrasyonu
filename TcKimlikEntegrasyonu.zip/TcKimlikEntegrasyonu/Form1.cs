﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using TcKimlikEntegrasyonu.KPSPublic;

namespace TcKimlikEntegrasyonu
{
    public partial class SorgulamaEkranı : Form
    {
        public SorgulamaEkranı()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private async void Sorgula_Click(object sender, EventArgs e)

        {

            string TcKimlik = textTcNumarasi.Text;
            string Ad = textAd.Text;
            string Soyad = textSoyad.Text;
            int DogumYili = Convert.ToInt32(textDogumYili.Text);

            KPSPublicSoapClient person = new KPSPublicSoapClient();
            bool result = person.TCKimlikNoDogrula(Convert.ToInt64(TcKimlik), Ad, Soyad, DogumYili);

            if (result)
            {
                MessageBox.Show("Geçerli Kimlik");
            }
            else
            {
                MessageBox.Show("Geçersiz kimlik");
            }
        }
    }
}
